<?php
  require_once('libs/utils.php');

  if (!is_auth())
    redirect('index.php');

  $db = new Db();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $employee_id = $_POST['employeeId'];
    $review = $_POST['review'];
    $comment = $_POST['comment'];

    if (isset($employee_id) && isset($review) && isset($comment)) {
      try {
        $db->set_review($employee_id, $review, $comment);
        http_response_code(200);
      } catch (Exception $e) {
        http_response_code(403);  
      }
    } else {
      http_response_code(401);
    }
    exit();
  }

  $reviews = $db->get_reviews();
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">
    <title>Manager Reviewing</title>
  </head>
  <body>
    <section class="jumbotron text-center">
      <div class="container">
        <h1 class="jumbotron-heading">Manager Reviewing</h1>
        <p>
          <a href="logout.php" class="btn btn-secondary my-2">Logout</a>
        </p>
      </div>
    </section>
    <div class="container">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">Employee #</th>
            <th scope="col">Review</th>
            <th scope="col">Comment</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
        <?php
          foreach ($reviews as $row) {
            #print_r($row);
            $employeeId =  htmlentities($row['EmployeeId']['S']);
            $review =  htmlentities($row['Review']['N']);
            $comment =   htmlentities($row['Comment']['S']);
            echo "<tr>
                    <th scope='row'>$employeeId</th>
                    <td id='review-$employeeId'>$review</td>
                    <td id='comment-$employeeId'>$comment</td>
                    <td><button type='button' class='btn btn-secondary' data-toggle='modal' data-target='#exampleModal' onclick='openModal(\"$employeeId\");'>Edit Review</button></td>
                  </tr>";
          }
          ?>
        </tbody>
      </table>
    </div>

    <div class="modal"  id="myModal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Edit Review</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="container">
            <div class="form-group">
              <label for="employeLabel">Employee Id</label>
              <input type="text" class="form-control" id="employeeInput" disabled>
            </div>
            <div class="form-group">
              <label for="reviewLabel">Review</label>
              <input type="text" class="form-control" id="reviewInput">
            </div>
            <div class="form-group">
              <label for="commentLabel">Comment</label>
              <textarea class="form-control" id="commentInput"></textarea>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-primary" onclick="updateReview()">Update Review</button>
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script>
    function openModal(employeeId) {
      document.getElementById("employeeInput").value = employeeId;
      document.getElementById("reviewInput").value = document.getElementById(`review-${employeeId}`).textContent;
      document.getElementById("commentInput").value = document.getElementById(`comment-${employeeId}`).textContent;

      $('#myModal').modal('show');
    }

    function updateReview() {
      var xhr = new XMLHttpRequest();
      xhr.open("POST", "", true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onreadystatechange = () => {
        if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
          location.reload();
        }
      }

      e = document.getElementById("employeeInput").value;
      r = document.getElementById("reviewInput").value;
      c = document.getElementById("commentInput").value;

      xhr.send(`employeeId=${e}&review=${r}&comment=${c}`);
    }
    </script>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>