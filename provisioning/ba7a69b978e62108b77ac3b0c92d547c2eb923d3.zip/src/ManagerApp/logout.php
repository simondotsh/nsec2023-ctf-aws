<?php
    require_once('libs/utils.php');
    session_destroy();

    redirect('index.php');
    exit();
?>