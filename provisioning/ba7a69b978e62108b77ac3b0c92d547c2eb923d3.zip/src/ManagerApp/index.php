<?php
  require_once('libs/utils.php');

  if (is_auth())
    redirect('app.php');

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $manager_id = $_POST['manager_id'];
    $password = $_POST['password'];

    if ($manager_id !== "" && $password !== "" && validate_credentials($manager_id, $password)) {
        $_SESSION['manager_id'] = $manager_id;
        redirect('app.php');
    } else {
      $error_message = "Invalid credentials.";
    }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/owl.carousel.min.css">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    
    <!-- Style -->
    <link rel="stylesheet" href="css/style.css">

    <title>Manager Login</title>
  </head>
  <body>
  

  <div class="d-lg-flex half">
    <div class="bg order-1 order-md-2" style="background-image: url('images/background.jpg');"></div>
    <div class="contents order-2 order-md-1">

      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-7">
            <?php
              if (isset($error_message))
                echo "<div class='alert alert-danger' role='alert'>$error_message</div>";
            ?>
            <form action="#" method="post">
              <div class="form-group first">
                <label for="manager_id">Manager Id</label>
                <input type="text" class="form-control" name="manager_id" required>
              </div>
              <div class="form-group last mb-4">
                <label for="password">Password</label>
                <input type="password" class="form-control" name="password" required>
              </div>

              <input type="submit" value="Log In" class="btn btn-block btn-secondary">

            </form>
            <div class="row align-items-center justify-content-center pt-5">
              <img src="images/powered-by-aws.png" alt="Powered by AWS Cloud Computing">
            </div>
          </div>
        </div>
      </div>
    </div>

    
  </div>
    
    

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
  </body>
</html>