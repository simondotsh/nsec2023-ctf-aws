#!/bin/bash

echo "==================================="
echo "EC2 Instance Maintenance Scheduled"
echo "==================================="
maintenances=$(curl -s http://169.254.169.254/latest/meta-data/events/maintenance/scheduled)
if [ "$maintenances" = "[]" ]; then
    echo No maintenance scheduled
else
    echo The next scheduled maintenances are: $maintenances
fi
echo

echo "==================================="
echo "Employee App Status"
echo "==================================="
curl -s http://employeeapp/status.php
echo
echo

echo "==================================="
echo "Manager App Status"
echo "==================================="
curl -s http://managerapp/status.php
echo
echo
