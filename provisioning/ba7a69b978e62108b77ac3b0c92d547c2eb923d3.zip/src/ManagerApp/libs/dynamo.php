<?php

  require_once('aws/aws-autoloader.php');

  class Db {
    private $tblLogin = 'GOD_LoginManager';
    private $tblReview = 'GOD_ReviewEmployee';
    private $db;
    
    function __construct() {
      $sdk = new Aws\Sdk([
        'region'   => 'us-east-1',
        'version'  => 'latest',
        'credentials' => [
          'key'    => 'KEY_PLACEHOLDER',
          'secret' => 'SECRET_PLACEHOLDER',
        ]
      ]);

      $this->db = $sdk->createDynamoDb();
    }

    function login($employee_id, $password) {
      $query = [
        'TableName' => $this->tblLogin,
        'KeyConditionExpression' => 'EmployeeId = :employee_id and Password = :password',
        'ExpressionAttributeValues' =>  [
            ':employee_id' => ['S' => $employee_id],
            ':password' => ['S' => $password]
        ]
      ];

      return count($this->db->query($query)['Items']) > 0 ? true: false;
    }

    function get_review($employee_id) {
      $query = [
        'TableName' => $this->tblReview,
        'KeyConditionExpression' => 'EmployeeId = :employee_id',
        'ExpressionAttributeValues' =>  [
            ':employee_id' => ['S' => $employee_id],
        ]
      ];

      return $this->db->query($query)['Items'];
    }

    function get_reviews() {
      $query = [
        'TableName' => $this->tblReview,
      ];

      return $this->db->scan($query)['Items'];
    }

    function set_review($employee_id, $review, $comment) {
      $this->db->updateItem([
        'Key' => [
          'EmployeeId' => [
              'S' => $employee_id
          ],
        ],
        'TableName' => $this->tblReview,
        'UpdateExpression' => "set #review=:review, #comment=:comment",
        'ExpressionAttributeNames' => [
            '#review' => 'Review',
            '#comment' => 'Comment'
        ],
        'ExpressionAttributeValues' => [
            ':review' => [
                'N' => $review
            ],
            ':comment' => [
              'S' => $comment
            ]
        ],
      ]);
    }
  }
?>